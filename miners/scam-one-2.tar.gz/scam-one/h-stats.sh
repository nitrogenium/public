#!/usr/bin/env bash

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

# khs=$(cat $CUSTOM_LOG_BASENAME.log|grep "Current hashrate"|tail -n 1|cut -f2 -d"]" | tr -dc '0-9.')
khs=0;
a=$(cat $CUSTOM_LOG_BASENAME.log |grep "Found"|wc -l)


last_fromn_log=$(cat $CUSTOM_LOG_BASENAME.log|tail -n 20| grep "Mining: id:"|tail -n 1|sed 's/: Mining/\n/g'|head -n 1)
last_log_entry=$(date --date="$last_fromn_log" +"%s")

start=$(cat $CUSTOM_DIR/start)
current_time=$(date +"%s")
uptime=$(echo "$current_time - $start"|bc)

total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

diff=$(echo "$current_time - $last_log_entry"|bc)

        if (( $(echo "$diff < 120" |bc -l) )); then

                # card_khs=$(echo "$khs / $total_gpu_count" | bc)

				echo $khs
				echo $card_khs
                counter=0
                hr_array=();

                while [ $counter -lt $total_gpu_count ]
                do

                		card_khs=$(cat $CUSTOM_LOG_BASENAME.log|tail -n 50|grep "GPU #$counter"|tail -n 1|cut -d "," -f2|cut -d ' ' -f2)
                		khs=$(echo "$khs + $card_khs"|bc)
                        hr_array+=($card_khs)
                        ((counter++))
                done

                #convert an array into a comma separated string
                delim=""
                joined=""
                for item in "${hr_array[@]}"; do
                  joined="$joined$delim$item"
                  delim=", "
                done

                stats=$(echo "{\"hs\": [$joined], \"hs_units\":\"khs\", \"algo\": \"randomx\", \"ar\": [$a, 0], \"uptime\": $uptime }")


        else

                stats='null'
                khs=0

        fi;


[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
