#!/usr/bin/env bash

. h-manifest.conf
CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR/JettonGramGpuMiner

total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

extra=$(<extra.txt)
runenv=$(<runenv.txt)

mode=$(echo $runenv | jq -r '.mode // "single"')
threads=$(echo $runenv | jq -r '.threads // 1')
single_file_name=$(echo $runenv | jq -r '.single_file_name // "send_universal.js"')
multi_file_name=$(echo $runenv | jq -r '.multi_file_name // "send_multigpu.js"')


echo "GPU Count: $total_gpu_count"
echo "Extra: $extra"

echo "Mode: $mode"
echo "Threads: $threads"
echo "Single file name: $single_file_name"
echo "Multi file name: $multi_file_name"

pwd

echo "Ready to start" >> exits


CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

if [[ "$mode" == "single" ]]; then

	echo "Single mode"
	
	for ((i=1; i<=threads; i++))
	do
	  
		counter=0
		while [ $counter -lt $total_gpu_count ]
		do

			while true; 
				do 

					node $single_file_name $extra --gpu $counter --bin ./pow-miner-cuda | tee -a $CUSTOM_LOG_BASENAME.log

					echo "=======> Died $counter" >> $CUSTOM_LOG_BASENAME.log;
					sleep $[ ( $RANDOM % 10 )  + 3 ]s;
				done &
			
			((counter++))
			sleep $[ ( $RANDOM % 8 )  + 2 ]s;

		done

	done

	wait

else

 	echo "Multi mode NOT TESTED SORRY"
	for ((i=1; i<=number; i++))
	do
		  echo "Iteration $i"
		  node $multi_file_name $extra --bin ./pow-miner-cuda --gpu-count $total_gpu_count | tee -a $CUSTOM_LOG_BASENAME.log &
		  sleep $[ ( $RANDOM % 10 )  + 3 ]s;
	done
fi