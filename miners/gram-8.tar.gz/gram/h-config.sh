CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf


cd $CUSTOM_DIR

DIR="JettonGramGpuMiner"

if [ -d "$DIR" ]; then
    cd "$DIR"
    git pull
else
    git clone https://github.com/TrueCarry/JettonGramGpuMiner.git
fi

cd JettonGramGpuMiner
npm install


[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1 #seed
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2 # apikey


length=$(echo $CUSTOM_TEMPLATE | jq length)
index=$(($RANDOM % $length))
random_w=$(echo $CUSTOM_TEMPLATE | jq -r .[$index])

length=$(echo $CUSTOM_URL | jq length)
index=$(($RANDOM % $length))
random_a=$(echo $CUSTOM_URL | jq -r .[$index])


extra="${CUSTOM_USER_CONFIG}"
conf="SEED=$random_w"$'\n'"TONAPI_TOKEN=$random_a"
runenv="${CUSTOM_PASS}"


echo "$runenv" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/runenv.txt
echo "$conf" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/config.txt
echo "$extra" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/extra.txt

