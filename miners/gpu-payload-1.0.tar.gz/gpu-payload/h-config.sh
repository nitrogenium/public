#!/usr/bin/env bash

[[ -e /hive/miners/custom2 ]] && . /hive/miners/custom2/gpu-payload/h-manifest.conf

conf=""

[[ ! -z $CUSTOM2_USER_CONFIG ]] && conf+=" $CUSTOM2_USER_CONFIG"

if [[ "$conf" =~ %WORKER_NAME% ]]; then
    if [[ -f /hive-config/rig.conf ]]; then
        source /hive-config/rig.conf
        worker_name="$WORKER_NAME"
    else
        worker_name="hiveos-worker"
    fi
    conf="${conf//%WORKER_NAME%/$worker_name}"
fi

if [[ "$conf" != *"--name="* ]]; then
    if [[ -f /hive-config/rig.conf ]]; then
        source /hive-config/rig.conf
        [[ ! -z "$WORKER_NAME" ]] && conf+=" --name=$WORKER_NAME"
    fi
fi

conf=$(echo "$conf" | sed 's/^ *//')

[[ -z $CUSTOM2_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM2_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM2_CONFIG_FILENAME