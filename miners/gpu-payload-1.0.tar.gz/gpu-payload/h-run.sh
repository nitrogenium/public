#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors
. h-manifest.conf

[[ -z $CUSTOM2_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM2_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM2_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM2_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM2_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM2_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

CUSTOM2_LOG_BASEDIR=`dirname "$CUSTOM2_LOG_BASENAME"`
[[ ! -d $CUSTOM2_LOG_BASEDIR ]] && mkdir -p $CUSTOM2_LOG_BASEDIR

echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES" > ./devices.ini

[[ ! -f $CUSTOM2_MINERBIN ]] && echo -e "${RED}Miner binary ${YELLOW}$CUSTOM2_MINERBIN${RED} is not found${NOCOLOR}" && exit 1

echo "Starting miner with config: $(< $CUSTOM2_CONFIG_FILENAME)"

./$CUSTOM2_MINERBIN $(< $CUSTOM2_CONFIG_FILENAME) $@ 2>&1 | tee $CUSTOM2_LOG_BASENAME.log