#!/usr/bin/env bash

CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR/JettonGramGpuMiner
npm install

. h-manifest.conf


total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

extra=$(<extra.txt)
echo "GPU Count: $total_gpu_count"
echo "Extra: $extra"
pwd

echo "Ready to start" >> exits

# sleep 10;
# counter=0
# while [ $counter -lt $total_gpu_count ]
# do

# 	while true; 
# 		do 
# 			# echo "Start $counter" >> exits;
# 			# miners/$miner/tonlib-$miner-cli -v 2 -C global.config.json -e "pminer start $giver $wallet $counter $boost $p_id" -s stats/pminer_$counter.json; 
# 			# /usr/bin/python3 hashtopolis.zip $(< $CUSTOM_NAME.conf) $@ 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log
			
# 			node send_universal.js --api tonhub --gpu $counter $(<extra) --bin ./pow-miner-cuda

# 			echo "Died $counter";
# 			sleep $[ ( $RANDOM % 10 )  + 3 ]s;
# 		done &
# 	# while true; do echo $counter; done &
# 	((counter++))
# 	sleep 7;
# done

# echo "Ready.."

# wait


node send_multigpu.js -$(<extra) --bin ./pow-miner-cuda --gpu-count $total_gpu_count


# CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
# [[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# LD_LIBRARY_PATH=./ ./fuckoff $(< ${CUSTOM_CONFIG_FILENAME})  | tee $CUSTOM_LOG_BASENAME.log

