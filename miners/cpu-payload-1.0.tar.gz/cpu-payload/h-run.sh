#!/usr/bin/env bash
set -euo pipefail

####################################################################################
###
### cpu-payload miner (Java Hashcat)
### Startup script for HiveOS
###
####################################################################################

# Загружаем манифест
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/h-manifest.conf"

# Проверяем наличие Java
if ! command -v java >/dev/null 2>&1; then
    echo "[h-run] ERROR: Java not found! Please install Java Runtime Environment."
    exit 1
fi

# 1) Подготовка
LOG_DIR="$(dirname "${CUSTOM_LOG_BASENAME}")"
mkdir -p "${LOG_DIR}"

# 2) Конфиг должен быть уже создан HiveOS через h-config.sh

# Проверяем наличие конфига
if [[ ! -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
    echo "[h-run] ERROR: Config file not found: ${CUSTOM_CONFIG_FILENAME}"
    exit 1
fi

# Проверяем наличие JAR файла
if [[ ! -f "${CUSTOM_BIN}" ]]; then
    echo "[h-run] ERROR: Miner binary not found: ${CUSTOM_BIN}"
    exit 1
fi

# Загружаем конфиг
echo "[h-run] Loading config from: ${CUSTOM_CONFIG_FILENAME}"
source "${CUSTOM_CONFIG_FILENAME}"

# Отладка: показываем загруженные переменные
echo "[h-run] Loaded config variables:" >&2
echo "  WALLET_WORKER='${WALLET_WORKER:-}'" >&2  
echo "  POOL_HOST='${POOL_HOST:-}'" >&2
echo "  POOL_PORT='${POOL_PORT:-}'" >&2
echo "  PASS='${PASS:-}'" >&2
echo "  THREADS='${THREADS:-}'" >&2
echo "  INSTANCES='${INSTANCES:-}'" >&2

# 3) Переход в каталог майнера и запуск
cd "${CUSTOM_MINER_DIR}"

echo "[h-run] Starting ${CUSTOM_NAME} v${CUSTOM_VERSION}"
echo "[h-run] System: ${CPU_CORES} CPU cores, ${GPU_COUNT} GPUs"
echo "[h-run] Launching ${INSTANCES} instances"
echo "[h-run] Pool: ${POOL_HOST}:${POOL_PORT}"
echo "[h-run] Wallet: ${WALLET_WORKER}"
echo "[h-run] Per instance: ${THREADS} threads, ${JAVA_OPTS}"

# Запускаем несколько экземпляров майнера (как в manul_run.txt)
MY_PID=$$

for i in $(seq 0 $((INSTANCES - 1))); do
    INSTANCE_WALLET="${WALLET_WORKER}_${i}"
    SCREEN_NAME="miner$((i+1))"
    LOG_FILE="${CUSTOM_LOG_BASENAME}_${i}.log"
    
    # Базовая команда запуска майнера
    CMD="java -jar ${JAVA_OPTS} ${CUSTOM_BIN} -u ${INSTANCE_WALLET} -h ${POOL_HOST} -p ${PASS} -t ${THREADS} -P ${POOL_PORT}"
    
    # Добавляем дополнительные параметры если есть (исключая наши служебные)
    if [[ -n "${EXTRA_ARGS:-}" ]]; then
        FILTERED_ARGS=$(echo "${EXTRA_ARGS}" | \
            sed 's/cores_formula="[^"]*"//g' | \
            sed 's/java_opts="[^"]*"//g' | \
            sed 's/java_opts=[^ ]*//g' | \
            sed 's/-t [0-9]*//g' | \
            sed 's/  */ /g' | \
            sed 's/^ *//g' | \
            sed 's/ *$//g')
        if [[ -n "${FILTERED_ARGS}" ]]; then
            CMD="${CMD} ${FILTERED_ARGS}"
        fi
    fi
    
    echo "[h-run] Instance $((i+1))/${INSTANCES}: ${CMD}"
    
    # Создаем batch для screen с автозавершением при завершении родительского процесса
    BATCH=$(cat <<EOF
(
    # Мониторинг родительского процесса
    ( while kill -0 $MY_PID 2>/dev/null; do sleep 1; done
      echo "Instance $((i+1)): parent died, shutting down miner..."
      kill \$\$ ) &
    
    # Перезапуск майнера при сбоях
    while true; do 
        echo "[\$(date)] Starting instance $((i+1))..."
        $CMD 2>&1 | tee -a "$LOG_FILE"
        echo "[\$(date)] Instance $((i+1)) exited, restarting in 5 seconds..."
        sleep 5
    done
)
EOF
)
    
    # Убиваем существующий screen если есть
    screen -S "$SCREEN_NAME" -X quit 2>/dev/null || true
    
    # Запускаем новый screen
    screen -dmS "$SCREEN_NAME" bash -c "$BATCH"
    
    sleep 1  # Небольшая задержка между запусками
done

echo "[h-run] All ${INSTANCES} instances started in screen sessions"
echo "[h-run] Use 'screen -list' to see running sessions"
echo "[h-run] Use 'screen -r miner1' to attach to first instance"

# Бесконечное ожидание (держим процесс живым)
while true; do
    sleep 10
    
    # Проверяем что хотя бы один экземпляр еще работает
    RUNNING=0
    for i in $(seq 0 $((INSTANCES - 1))); do
        SCREEN_NAME="miner$((i+1))"
        if screen -list | grep -q "$SCREEN_NAME"; then
            RUNNING=1
            break
        fi
    done
    
    if [[ $RUNNING -eq 0 ]]; then
        echo "[h-run] All instances have stopped, exiting"
        exit 1
    fi
done 