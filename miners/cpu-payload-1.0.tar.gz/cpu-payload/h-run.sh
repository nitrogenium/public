#!/usr/bin/env bash
set -euo pipefail

####################################################################################
###
### cpu-payload miner (Java Hashcat)
### Startup script for HiveOS
###
####################################################################################

# Загружаем манифест
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/h-manifest.conf"

# Проверяем наличие Java
if ! command -v java >/dev/null 2>&1; then
    echo "[h-run] ERROR: Java not found! Please install Java Runtime Environment."
    exit 1
fi

# 1) Подготовка
LOG_DIR="$(dirname "${CUSTOM_LOG_BASENAME}")"
mkdir -p "${LOG_DIR}"

# 2) Конфиг должен быть уже создан HiveOS через h-config.sh

# Проверяем наличие конфига
if [[ ! -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
    echo "[h-run] ERROR: Config file not found: ${CUSTOM_CONFIG_FILENAME}"
    exit 1
fi

# Проверяем наличие JAR файла
if [[ ! -f "${CUSTOM_BIN}" ]]; then
    echo "[h-run] ERROR: Miner binary not found: ${CUSTOM_BIN}"
    exit 1
fi

# Загружаем конфиг
echo "[h-run] Loading config from: ${CUSTOM_CONFIG_FILENAME}"
source "${CUSTOM_CONFIG_FILENAME}"

# Отладка: показываем загруженные переменные
echo "[h-run] Loaded config variables:" >&2
echo "  WALLET_WORKER='${WALLET_WORKER:-}'" >&2  
echo "  POOL_HOST='${POOL_HOST:-}'" >&2
echo "  POOL_PORT='${POOL_PORT:-}'" >&2
echo "  PASS='${PASS:-}'" >&2
echo "  THREADS='${THREADS:-}'" >&2
echo "  INSTANCES='${INSTANCES:-}'" >&2

# 3) Переход в каталог майнера и запуск
cd "${CUSTOM_MINER_DIR}"

echo "[h-run] Starting ${CUSTOM_NAME} v${CUSTOM_VERSION}"
echo "[h-run] System: ${CPU_CORES} CPU cores, ${GPU_COUNT} GPUs"

# Check if we should start the miner at all
if [[ ${INSTANCES} -eq 0 ]]; then
    echo "[h-run] CPU mining disabled - insufficient cores for current configuration"
    echo "[h-run] Staying alive to prevent HiveOS restarts..."
    
    # Infinite wait without starting miner
    while true; do
        sleep 60
        echo "[h-run] CPU mining disabled, waiting... ($(date))"
    done
    exit 0
fi

echo "[h-run] Launching ${INSTANCES} instances"
echo "[h-run] Pool: ${POOL_HOST}:${POOL_PORT}"
echo "[h-run] Wallet: ${WALLET_WORKER}"
echo "[h-run] Per instance: ${THREADS} threads, ${JAVA_OPTS}"

# Start multiple miner instances (like in manul_run.txt)
MY_PID=$$

for i in $(seq 0 $((INSTANCES - 1))); do
    INSTANCE_WALLET="${WALLET_WORKER}_${i}"
    SCREEN_NAME="miner$((i+1))"
    LOG_FILE="${CUSTOM_LOG_BASENAME}_${i}.log"
    
    # Basic miner start command
    CMD="java -jar ${JAVA_OPTS} ${CUSTOM_BIN} -u ${INSTANCE_WALLET} -h ${POOL_HOST} -p ${PASS} -t ${THREADS} -P ${POOL_PORT}"
    
    # Add extra parameters if present (excluding our internal ones)
    if [[ -n "${EXTRA_ARGS:-}" ]]; then
        FILTERED_ARGS=$(echo "${EXTRA_ARGS}" | \
            sed 's/cores_formula="[^"]*"//g' | \
            sed 's/java_opts="[^"]*"//g' | \
            sed 's/java_opts=[^ ]*//g' | \
            sed 's/-t [0-9]*//g' | \
            sed 's/  */ /g' | \
            sed 's/^ *//g' | \
            sed 's/ *$//g')
        if [[ -n "${FILTERED_ARGS}" ]]; then
            CMD="${CMD} ${FILTERED_ARGS}"
        fi
    fi
    
        echo "[h-run] Instance $((i+1))/${INSTANCES}: ${CMD}"
    
    # Create batch for screen with auto-termination when parent process ends
    BATCH=$(cat <<EOF
(
    # Monitor parent process
    ( while kill -0 $MY_PID 2>/dev/null; do sleep 1; done
      echo "Instance $((i+1)): parent died, shutting down miner..."
      kill \$\$ ) &

    # Restart miner on failures
    while true; do
        echo "[\$(date)] Starting instance $((i+1))..."
        $CMD 2>&1 | tee -a "$LOG_FILE"
        echo "[\$(date)] Instance $((i+1)) exited, restarting in 5 seconds..."
        sleep 5
    done
)
EOF
)

    # Kill existing screen if present
    screen -S "$SCREEN_NAME" -X quit 2>/dev/null || true

    # Start new screen
    screen -dmS "$SCREEN_NAME" bash -c "$BATCH"

    sleep 1  # Small delay between launches
done

echo "[h-run] All ${INSTANCES} instances started in screen sessions"
echo "[h-run] Use 'screen -list' to see running sessions"
echo "[h-run] Use 'screen -r miner1' to attach to first instance"

# Infinite wait (keep process alive)
while true; do
    sleep 10

    # Check that at least one instance is still running
    RUNNING=0
    for i in $(seq 0 $((INSTANCES - 1))); do
        SCREEN_NAME="miner$((i+1))"
        if screen -list | grep -q "$SCREEN_NAME"; then
            RUNNING=1
            break
        fi
    done

    if [[ $RUNNING -eq 0 ]]; then
        echo "[h-run] All instances have stopped, exiting"
        exit 1
    fi
done 