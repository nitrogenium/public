#!/usr/bin/env bash
set -euo pipefail

####################################################################################
###
### cpu-payload miner (Java Hashcat)
### Statistics parser for HiveOS
###
####################################################################################

# Load manifest
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

# Save environment CUSTOM_LOG_BASENAME if provided
SAVED_LOG_BASENAME="${CUSTOM_LOG_BASENAME:-}"

source "${SCRIPT_DIR}/h-manifest.conf"

# Restore environment CUSTOM_LOG_BASENAME if it was set
if [[ -n "${SAVED_LOG_BASENAME}" ]]; then
    CUSTOM_LOG_BASENAME="${SAVED_LOG_BASENAME}"
fi

# Small utility: safe JSON echo on one line
json_print() { 
    if command -v jq >/dev/null 2>&1; then
        jq -c -M '.' <<<"$1"
    else
        echo "$1"
    fi
}

# Function to get statistics from one instance
get_instance_stats() {
    local log_file="$1"
    
    if [[ ! -f "$log_file" ]]; then
        echo "0|0|0|0"
        return
    fi
    
    # Look for last lines with statistics
    local miner_stats=$(tail -50 "$log_file" | grep "Miner Stats:" | tail -1)
    local pool_stats=$(tail -50 "$log_file" | grep "Pool Stats:" | tail -1)
    
    # Parse miner statistics
    local sols_per_sec="0"
    local kcycles_per_sec="0"
    if [[ -n "$miner_stats" ]]; then
        sols_per_sec=$(echo "$miner_stats" | grep -o '[0-9]*\.[0-9]* Sol/s' | grep -o '[0-9]*\.[0-9]*' || echo "0")
        kcycles_per_sec=$(echo "$miner_stats" | grep -o '[0-9]* kcycles/s' | grep -o '[0-9]*' || echo "0")
    fi
    
    # Parse pool statistics
    local accepted="0"
    local rejected="0"
    if [[ -n "$pool_stats" ]]; then
        if echo "$pool_stats" | grep -q "(\([0-9]*\) Accepted, \([0-9]*\) Rejected)"; then
            accepted=$(echo "$pool_stats" | sed -n 's/.*(\([0-9]*\) Accepted, \([0-9]*\) Rejected).*/\1/p')
            rejected=$(echo "$pool_stats" | sed -n 's/.*(\([0-9]*\) Accepted, \([0-9]*\) Rejected).*/\2/p')
        fi
    fi
    
    echo "${sols_per_sec}|${kcycles_per_sec}|${accepted}|${rejected}"
}

# Function to get aggregated statistics from all instances
get_miner_stats() {
    local instances=1
    local total_sols="0"
    local total_kcycles="0"
    local total_accepted="0"
    local total_rejected="0"
    
    # Get number of instances from config if available
    if [[ -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
        source "${CUSTOM_CONFIG_FILENAME}" 2>/dev/null || true
        if [[ -n "${INSTANCES}" ]]; then
            instances="${INSTANCES}"
        fi
    fi
    
    # Collect statistics from each instance
    for i in $(seq 0 $((instances - 1))); do
        local log_file="${CUSTOM_LOG_BASENAME}_${i}.log"
        # Also check main log file for compatibility
        if [[ $i -eq 0 && ! -f "$log_file" && -f "${CUSTOM_LOG_BASENAME}.log" ]]; then
            log_file="${CUSTOM_LOG_BASENAME}.log"
        fi
        
        local stats=$(get_instance_stats "$log_file")
        IFS='|' read -r sols kcycles accepted rejected <<< "$stats"
        
        # Use bc for precise floating point calculations
        if command -v bc >/dev/null 2>&1; then
            total_sols=$(echo "$total_sols + $sols" | bc -l)
            total_kcycles=$(echo "$total_kcycles + $kcycles" | bc -l)
        else
            # Fallback without bc - integers only
            total_sols=$(awk "BEGIN {print $total_sols + $sols}")
            total_kcycles=$(awk "BEGIN {print $total_kcycles + $kcycles}")
        fi
        
        total_accepted=$((total_accepted + accepted))
        total_rejected=$((total_rejected + rejected))
    done
    
    echo "${total_sols}|${total_kcycles}|${total_accepted}|${total_rejected}"
}

# 1) Get statistics
stats_raw=$(get_miner_stats)

if [[ -z "$stats_raw" || "$stats_raw" == "0|0|0|0" ]]; then
    # No data - return zero statistics
    ZERO_STATS='{
        "hs": [0],
        "hs_units": "sols",
        "algo": "cuckoo",
        "ver": "'${CUSTOM_VERSION}'",
        "shares": [0, 0],
        "uptime": 0
    }'
    json_print "$ZERO_STATS"
    exit 0
fi

# Parse received data
IFS='|' read -r sols_per_sec kcycles_per_sec accepted rejected <<< "$stats_raw"

# Check data correctness
[[ -z "$sols_per_sec" || "$sols_per_sec" == "0" ]] && sols_per_sec="0"
[[ -z "$kcycles_per_sec" ]] && kcycles_per_sec="0"
[[ -z "$accepted" ]] && accepted="0"
[[ -z "$rejected" ]] && rejected="0"

# Get uptime from log (approximately)
uptime="0"
if [[ -f "${CUSTOM_LOG_BASENAME}.log" ]]; then
    # Look for start time and last entry
    first_line=$(head -1 "${CUSTOM_LOG_BASENAME}.log" 2>/dev/null | grep -o '\[.*\]' | tr -d '[]' || echo "")
    last_line=$(tail -1 "${CUSTOM_LOG_BASENAME}.log" 2>/dev/null | grep -o '\[.*\]' | tr -d '[]' || echo "")
    
    if [[ -n "$first_line" && -n "$last_line" ]]; then
        # Simple calculation - can be improved
        start_time=$(date -d "$first_line" +%s 2>/dev/null || echo "0")
        end_time=$(date -d "$last_line" +%s 2>/dev/null || echo "0")
        if [[ "$start_time" -gt 0 && "$end_time" -gt 0 ]]; then
            uptime=$((end_time - start_time))
        fi
    fi
fi

# Get algorithm from config if available
ALGO="cuckoo"
if [[ -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
    source "${CUSTOM_CONFIG_FILENAME}" 2>/dev/null || true
    [[ -n "${ALGO}" ]] && ALGO="${ALGO}"
fi

# 4) Form final JSON
# For CPU miner use array with single element
OUT='{
    "hs": ['$sols_per_sec'],
    "hs_units": "sols",
    "algo": "'${ALGO}'",
    "ver": "'${CUSTOM_VERSION}'",
    "shares": ['$accepted', '$rejected'],
    "uptime": '$uptime',
    "kcycles_per_sec": '$kcycles_per_sec'
}'

json_print "$OUT"

# Debug information to stderr (doesn't affect JSON)
echo "[h-stats] Total Sol/s: $sols_per_sec, Shares: $accepted/$rejected, Uptime: $uptime, Instances: ${INSTANCES:-1}" >&2 