#!/usr/bin/env bash
set -euo pipefail

####################################################################################
###
### cpu-payload miner (Java Hashcat)
### Configuration generator for HiveOS
###
####################################################################################

# Загружаем манифест
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

# Сохраняем переданные через окружение переменные если есть
SAVED_CONFIG_FILENAME="${CUSTOM_CONFIG_FILENAME:-}"

source "${SCRIPT_DIR}/h-manifest.conf"

# Восстанавливаем переданные через окружение переменные если были заданы
if [[ -n "${SAVED_CONFIG_FILENAME}" ]]; then
    CUSTOM_CONFIG_FILENAME="${SAVED_CONFIG_FILENAME}"
fi

echo "CUSTOM_TEMPLATE =         ${CUSTOM_TEMPLATE:-}"
echo "CUSTOM_URL =              ${CUSTOM_URL:-}"
echo "CUSTOM_PASS =             ${CUSTOM_PASS:-}"
echo "CUSTOM_ALGO =             ${CUSTOM_ALGO:-}"
echo "CUSTOM_USER_CONFIG =      ${CUSTOM_USER_CONFIG:-}"
echo "CUSTOM_CONFIG_FILENAME =  ${CUSTOM_CONFIG_FILENAME}"

# Парсим URL пула
POOL_HOST=""
POOL_PORT=""
if [[ -n "${CUSTOM_URL:-}" ]]; then
    # Парсим URL вида stratum+tcp://host:port или host:port
    POOL_URL="${CUSTOM_URL}"
    POOL_URL="${POOL_URL#*://}"  # убираем протокол если есть
    
    # Проверяем есть ли порт в URL
    if [[ "$POOL_URL" == *":"* ]]; then
        POOL_HOST="${POOL_URL%:*}"   # хост до :
        POOL_PORT="${POOL_URL#*:}"   # порт после :
    else
        # Если порта нет, используем весь URL как хост
        POOL_HOST="$POOL_URL"
        POOL_PORT="5001"  # порт по умолчанию
    fi
    
    # Убираем лишние пробелы
    POOL_HOST=$(echo "$POOL_HOST" | tr -d ' \t\n\r')
    POOL_PORT=$(echo "$POOL_PORT" | tr -d ' \t\n\r')
fi

# Отладка парсинга URL
echo "[h-config] URL parsing: '$CUSTOM_URL' -> '$POOL_HOST':'$POOL_PORT'" >&2

# Используем CUSTOM_TEMPLATE напрямую (содержит кошелек и воркер)
WALLET_WORKER="${CUSTOM_TEMPLATE:-}"

# Пароль
PASS="${CUSTOM_PASS:-x}"

# Алгоритм (используем тот что пришел от HiveOS)
ALGO="${CUSTOM_ALGO:-cuckoo}"

# Определяем системные ресурсы
CPU_CORES=$(nproc 2>/dev/null || echo "4")  # Количество ядер CPU (работает в Docker)

# Определяем количество GPU (если команда gpu-stats доступна)
GPU_COUNT=0
if command -v gpu-stats >/dev/null 2>&1; then
    GPU_COUNT=$(gpu-stats 2>/dev/null | jq -r ".brand" 2>/dev/null | grep -i 'nvidia\|amd' | wc -l 2>/dev/null | tr -d '\n' || echo "0")
fi
# Убеждаемся что это число
[[ "$GPU_COUNT" =~ ^[0-9]+$ ]] || GPU_COUNT=0

# Стратегии расчета количества экземпляров майнера  
INSTANCES=""
THREADS=""
JAVA_OPTS=""

# Парсим параметры из CUSTOM_USER_CONFIG
if [[ -n "${CUSTOM_USER_CONFIG:-}" ]]; then
    # ФОРМУЛА (единственный способ кастомизации)
    if [[ -z "$INSTANCES" ]] && echo "${CUSTOM_USER_CONFIG}" | grep -q "cores_formula="; then
        # cores_formula="CPU-GPU*2-1" → вычисляем формулу
        FORMULA=$(echo "${CUSTOM_USER_CONFIG}" | sed -n 's/.*cores_formula="\([^"]*\)".*/\1/p')
        if [[ -n "$FORMULA" ]]; then
            # Заменяем CPU и GPU на значения
            FORMULA_EVAL=$(echo "$FORMULA" | sed "s/CPU/$CPU_CORES/g" | sed "s/GPU/$GPU_COUNT/g")
            echo "[h-config] Formula: '$FORMULA' -> '$FORMULA_EVAL'" >&2
            # Проверяем что формула содержит только безопасные символы (простая проверка)
            if [[ "$FORMULA_EVAL" =~ ^[0-9+*/()[:space:]-]+$ ]]; then
                RESULT=$(echo "$FORMULA_EVAL" | bc -l 2>/dev/null || echo "error")
                if [[ "$RESULT" != "error" ]] && [[ "$RESULT" =~ ^-?[0-9.]+$ ]]; then
                    INSTANCES=$(printf "%.0f" "$RESULT" 2>/dev/null || echo "0")  # Округляем до целого
                    [[ $INSTANCES -lt 0 ]] && INSTANCES=0
                    echo "[h-config] Formula result: $INSTANCES" >&2
                else
                    echo "[h-config] Formula calculation error: $RESULT" >&2
                fi
            else
                echo "[h-config] Formula contains invalid characters: '$FORMULA_EVAL'" >&2
            fi
        fi
    fi
    
    # Ищем параметр -t для количества потоков на экземпляр
    if echo "${CUSTOM_USER_CONFIG}" | grep -q "\-t"; then
        THREADS=$(echo "${CUSTOM_USER_CONFIG}" | grep -o "\-t [0-9]*" | awk '{print $2}' | head -1)
    fi
    
    # Ищем полные Java параметры через java_opts=
    if echo "${CUSTOM_USER_CONFIG}" | grep -q "java_opts="; then
        # Извлекаем всё что в кавычках после java_opts=
        JAVA_OPTS=$(echo "${CUSTOM_USER_CONFIG}" | sed -n 's/.*java_opts="\([^"]*\)".*/\1/p')
        # Если нет кавычек, берём до следующего пробела
        if [[ -z "$JAVA_OPTS" ]]; then
            JAVA_OPTS=$(echo "${CUSTOM_USER_CONFIG}" | grep -o "java_opts=[^ ]*" | cut -d= -f2)
        fi
    fi
fi

# Рассчитываем количество экземпляров если не задано (по умолчанию: все ядра)
if [[ -z "$INSTANCES" ]]; then
    INSTANCES=$CPU_CORES
fi

# Минимум 1 экземпляр
[[ $INSTANCES -lt 1 ]] && INSTANCES=1

# Рассчитываем потоки на экземпляр если не заданы явно (по умолчанию: 3)
if [[ -z "$THREADS" ]]; then
    THREADS=3
fi

# Используем -Xmx8G по умолчанию если не задано
if [[ -z "$JAVA_OPTS" ]]; then
    JAVA_OPTS="-Xmx8G"
fi

# Убедимся, что каталог существует
mkdir -p "$(dirname "${CUSTOM_CONFIG_FILENAME}")"

# Создаем конфиг файл с параметрами запуска
cat > "${CUSTOM_CONFIG_FILENAME}" <<EOF
# cpu-payload miner configuration
# Generated by h-config.sh

WALLET_WORKER="${WALLET_WORKER}"
POOL_HOST="${POOL_HOST}"
POOL_PORT="${POOL_PORT}"
PASS="${PASS}"
THREADS="${THREADS}"
JAVA_OPTS="${JAVA_OPTS}"
ALGO="${ALGO}"
INSTANCES="${INSTANCES}"
CPU_CORES="${CPU_CORES}"
GPU_COUNT="${GPU_COUNT}"
EXTRA_ARGS="${CUSTOM_USER_CONFIG:-}"
EOF

echo "[h-config] Wrote config: ${CUSTOM_CONFIG_FILENAME}"
echo "[h-config] System: ${CPU_CORES} CPU cores, ${GPU_COUNT} GPUs"
echo "[h-config] Instances: ${INSTANCES}"
echo "[h-config] Pool: ${POOL_HOST}:${POOL_PORT}"
echo "[h-config] Wallet: ${WALLET_WORKER}"
echo "[h-config] Per instance: ${THREADS} threads, ${JAVA_OPTS}"
echo "[h-config] Algorithm: ${ALGO}" 