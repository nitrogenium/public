CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

extra="${CUSTOM_USER_CONFIG}"
conf="SEED=${CUSTOM_TEMPLATE}\nTONAPI_TOKEN=${CUSTOM_URL}"


echo "$conf" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/config.txt
echo "$extra" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/extra.txt


#check  Node.js
if command -v node >/dev/null 2>&1; then
    NODE_VERSION=$(node -v)
    echo "current version Node.js: $NODE_VERSION"
    
    if [[ $NODE_VERSION == v20* ]]; then
        echo "Node.js 20 already installed."
    else
    	echo "Uninstall old nodejs "
    	sudo apt-get remove -y nodejs
        echo "start installation of  Node.js 20 version ..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs
    fi
else
    echo "Node.js not installed. Starting installatinon..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs
fi