CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

extra="${CUSTOM_USER_CONFIG}"
conf="SEED=${CUSTOM_TEMPLATE}"$'\n'"TONAPI_TOKEN=${CUSTOM_URL}"
mode="${CUSTOM_PASS}"


echo "$mode" > /hive/miners/custom/${CUSTOM_NAME}/JettonJPTRGpuMiner-main/mode.txt
echo "$conf" > /hive/miners/custom/${CUSTOM_NAME}/JettonJPTRGpuMiner-main/config.txt
echo "$extra" > /hive/miners/custom/${CUSTOM_NAME}/JettonJPTRGpuMiner-main/extra.txt

