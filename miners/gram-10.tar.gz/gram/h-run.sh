#!/usr/bin/env bash

. h-manifest.conf
CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR/JettonGramGpuMiner
npm install




total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

extra=$(<extra.txt)
mode=$(<mode.txt)
echo "GPU Count: $total_gpu_count"
echo "Extra: $extra"
echo "mode: $mode"
pwd

echo "Ready to start" >> exits


CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR


# Проверяем наличие 'X' в переменной
if [[ $mode == *"X"* ]]; then
  has_x="true"
else
  has_x="false"
fi

# Извлекаем число из переменной, если есть; по умолчанию число равно 1
number=$(echo $mode | grep -o '[0-9]\+' || echo "1")

echo "has_x=$has_x"
echo "Копии=$number"



if [ "$has_x" = "true" ]; then

	echo "Single mode"
	
	for ((i=1; i<=number; i++))
	do
	  
	 
	  
		counter=0
		while [ $counter -lt $total_gpu_count ]
		do

			while true; 
				do 

					node send_jptr.js $extra --gpu $counter --bin ./pow-miner-cuda | tee -a $CUSTOM_LOG_BASENAME.log

					echo "=======> Died $counter" >> $CUSTOM_LOG_BASENAME.log;
					sleep $[ ( $RANDOM % 10 )  + 3 ]s;
				done &
			
			((counter++))
			sleep 7;

		done


	done

	wait


else

 	echo "Multi mode"
	for ((i=1; i<=number; i++))
	do
		  echo "Iteration $i"
		  node send_multigpu_jptr2.js $extra --bin ./pow-miner-cuda --gpu-count $total_gpu_count | tee -a $CUSTOM_LOG_BASENAME.log &
		  sleep $[ ( $RANDOM % 10 )  + 3 ]s;
	done
fi





# CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
# [[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# LD_LIBRARY_PATH=./ ./fuckoff $(< ${CUSTOM_CONFIG_FILENAME})  | tee $CUSTOM_LOG_BASENAME.log

