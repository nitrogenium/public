#!/usr/bin/env bash

get_hashrate(){
        local khs=$(grep ' Total hashrate: ' ${LOG_NAME} | tail -n1 | perl -ne 'if (/Total hashrate: ([0-9]+(\.[0-9]+)?) (([kmg])h\/s)/i) { print $1 * ($4 eq "g" ? 1000000 : ($4 eq "m" ? 1000 : 1)), "\n" }')
        [[ -z $khs ]] && khs=0
        echo "$khs"
}

get_cards_hashes(){
        grep -P '[gmk]h\/s' ${LOG_NAME} | grep -v ' Total hashrate: ' | tail -n${GPU_COUNT} \
        | perl -ne 'if (/: ([0-9]+(\.[0-9]+)?) (([kmg])h\/s)/i) { print $1 * ($4 eq "g" ? 1000000 : ($4 eq "m" ? 1000 : 1)), "\n" }' \
        | jq -cs '.'
}

get_mined_blocks(){
        grep ' Mined block ' ${LOG_NAME}  | wc -l
}

get_miner_uptime(){
        ps -o etimes= -C $CUSTOM_NAME | awk '{print $1}'
}

get_log_time_diff(){
        local last_log=`tail -n 1 ${LOG_NAME} | awk {'print $1,$2'} | sed 's/[][]//g'`
        local last_log_unix=`date --date="$last_log" +%s`
        local cur_time_unix=`date +%s`
        echo `expr $cur_time_unix - $last_log_unix`
}

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf

LOG_NAME="$CUSTOM_LOG_BASENAME.log"

[[ -z $GPU_COUNT_NVIDIA ]] &&
    GPU_COUNT_NVIDIA=`gpu-detect NVIDIA`
[[ -z $GPU_COUNT_AMD ]] &&
    GPU_COUNT_AMD=`gpu-detect AMD`

# Calculate total GPU amount
GPU_COUNT=`expr $GPU_COUNT_NVIDIA + $GPU_COUNT_AMD`

local diffTime=$(get_log_time_diff)
local maxDelay=60

if [ "$diffTime" -lt "$maxDelay" ]
then
        local temp=$(jq -c ".temp" <<< $gpu_stats)
        local fan=$(jq -c ".fan" <<< $gpu_stats)

        [[ $cpu_indexes_array != '[]' ]] &&
                temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
                fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

        local ac=$(get_mined_blocks)
        local hr=$(get_hashrate)
        local hs=$(get_cards_hashes)

        stats=$(jq -nc \
                --argjson hr "$hr" \
                --argjson hs "$hs" \
                --arg hs_units "khs" \
                --argjson temp "$temp" \
                --argjson fan "$fan" \
                --argjson uptime "$(get_miner_uptime)" \
                --argjson ac "$ac" \
                --arg algo "sha256d" \
                '{total_khs: $hr, $hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, 0], $algo}')
        khs="$hr"
else
        stats=""
        khs=0
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"

#echo "$stats"
#echo "$khs"
