#!/usr/bin/env bash


# {"action": "sendProgress", "token": "ozf7yq9C3F", "chunkId": 16, "keyspaceProgress": 3356702, "relativeProgress": 1347, "speed": 706883, "state": 2, "cracks": [], "gpuTemp": [59, 64, 58, 60, 58, 60, 59, 58], "gpuUtil": [100, 95, 44, 85, 65, 21, 100, 100], "cpuUtil": [99.7]}



  STATS=/var/log/miner/hashcat/stat.json
  now=$(date +%s)
  upd=$(stat -c %Y $STATS 2>/dev/null)
  if (( $? == 0 && upd + 180 > now )); then
    readarray -t arr < <(jq -rc '.speed, .gpuUtil, .gpuTemp' $STATS)
    
    khs=${arr[0]}
    hs=${arr[1]}
    temps=${arr[2]}
  

  else
    hash_arr="null"
    bus_numbers="null"
    khs=0
    ac=0
    rj=0
    ver="$CUSTOM_VERSION"
    uptime=0
    temp="null"
    fan="null"
    echo "No stats json"
  fi

  # stats=$(jq -n --arg algo "$algo" --argjson bus_numbers "$bus_numbers" --argjson hs "$hash_arr" \
  #         --arg uptime "$uptime" --arg ver "$ver" --argjson temp "$temp" --argjson fan "$fan" \
  #         '{hs_units: "hs", $hs, $algo, $ver, $uptime, $bus_numbers, $fan, $temp, ar:[$ac|tonumber,$rj|tonumber]}')


   stats=$(jq -n \
        --argjson hs "$hs" -arg hs_units hs \
        --argjson temp "$temps" \
        --arg total_khs "$khs" \
        --arg algo darkcoin \
        --arg ver 1 \
        '{$hs, $hs_units, $temp, $fan, $algo, $uptime, $ver, ar: [$ac, $rj]}')



#######################
# MAIN script body
#######################

# . /hive/miners/custom/dynexsolve/h-manifest.conf

# local algo="cryptonight"

# stats=""
# khs=0

# if true; then
#   get_json_stats
# else
#   local temp=$(jq '.temp' <<< $gpu_stats)
#   local fan=$(jq '.fan' <<< $gpu_stats)

#   temp=$(jq -rc ".$nvidia_indexes_array" <<< $temp)
#   fan=$(jq -rc ".$nvidia_indexes_array" <<< $fan)

#   local log_name="$CUSTOM_LOG_BASENAME.log"
#   local conf_name="$CUSTOM_CONFIG_FILENAME"

#   local ac=0
#   local rj=0

#   [[ -z $GPU_COUNT_NVIDIA ]] && GPU_COUNT_NVIDIA=`gpu-detect NVIDIA`

#   # Calc log freshness
#   local diffTime=$(get_log_time_diff)
#   local maxDelay=120

#   # echo $diffTime

#   # If log is fresh the calc miner stats or set to null if not
#   if [[ "$diffTime" -lt "$maxDelay" ]]; then
#     get_log_tail
#     get_cards_hashes                 # hashes
#     get_total_hashes                 # total hashes
#     get_shares                       # accepted, rejected
#     local hs_units='hs'              # hashes utits
#     local uptime=$(get_miner_uptime) # miner uptime

#     get_sol

#     # make JSON
#     #--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \

#     stats=$(jq -nc \
#         --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
#         --arg hs_units "$hs_units" \
#         --argjson temp "`echo ${temp[@]} | tr " " "\n" | jq -cs '.'`" \
#         --argjson fan "`echo ${fan[@]} | tr " " "\n" | jq -cs '.'`" \
#         --arg ac "$ac" --arg rj "$rj" \
#         --arg uptime "$uptime" \
#         --arg algo "$algo" \
#         --arg ver "$CUSTOM_VERSION" \
#         '{$hs, $hs_units, $temp, $fan, $uptime, $algo, ar: [$ac, $rj], $ver}')
#   fi
# fi

# debug output
#echo temp:  $temp
#echo fan:   $fan
#echo stats: $stats
#echo khs:   $khs
