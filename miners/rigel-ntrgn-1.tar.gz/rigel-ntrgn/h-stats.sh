#!/usr/bin/env bash

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

J=$(curl 127.0.0.1:5000)

echo ${CUSTOM_ALGO}
echo $J

if jq -e . >/dev/null 2>&1 <<<"$J"; then
    echo "Parsed JSON successfully and got something other than false/null"

    hrs=$(jq ".devices | .[] | .hashrate | .${CUSTOM_ALGO}" <<< $J | paste -sd, -)
    temps=$(jq ".devices | .[] | .monitoring_info.core_temperature" <<< $J | paste -sd, -)
    fans=$(jq ".devices | .[] | .monitoring_info.fan_speed" <<< $J | paste -sd, -)
    total=$(jq ".hashrate.${CUSTOM_ALGO}" <<< $J)

    khs=$(echo "$total / 1000"|bc)
   

    echo $total

else
    echo "Failed to parse JSON, or got false/null"

    hash_arr="null"
    bus_numbers="null"
    khs=0
    ac=0
    rj=0
    ver="$CUSTOM_VERSION"
    uptime=0
    temp="null"
    fan="null"
    echo "No stats json"
fi




 stats=$(jq -n \
        --argjson hs "[$hrs]" --arg hs_units hs \
        --argjson temp "[$temps]" \
        --argjson fan "[$fans]" \
        --arg algo ${CUSTOM_ALGO} \
        --arg ver 1 \
        '{$hs, $hs_units, $fan, $temp,  $algo, $ver, total_khs}')


  [[ -z $khs ]] && khs=0
  [[ -z $stats ]] && stats="null"


# debug output
#echo temp:  $temp
#echo fan:   $fan
#echo stats: $stats
#echo khs:   $khs
