#!/usr/bin/env bash

. h-manifest.conf
CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR/JettonJPTRGpuMiner-main
npm install




total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

extra=$(<extra.txt)
mode=$(<mode.txt)
echo "GPU Count: $total_gpu_count"
echo "Extra: $extra"
echo "mode: $mode"
pwd

echo "Ready to start" >> exits


CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR


echo "Multi mode"


node send_multigpu_jptr2.js $extra --bin ./pow-miner-cuda --gpu-count $total_gpu_count | tee -a $CUSTOM_LOG_BASENAME.log &




