
#CUSTOM_URL_HOST=`echo $CUSTOM_URL | cut -d ":" -f1`
#CUSTOM_URL_PORT=`echo $CUSTOM_URL | cut -d ":" -f2`

conf="--gpu -a ${CUSTOM_TEMPLATE} ${CUSTOM_USER_CONFIG}"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

