#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
#[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2


#total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

# echo "--threads $total_gpu_count --kaspad-address $CUSTOM_URL --mining-address $CUSTOM_TEMPLATE" > $CUSTOM_CONFIG_FILENAME
# echo "-t 0 --kaspad-address $CUSTOM_URL --mining-address $CUSTOM_TEMPLATE" > $CUSTOM_CONFIG_FILENAME

echo "-mining-address $CUSTOM_TEMPLATE -daemon-host dynex-node.neuropool.net -no-cpu -multi-gpu -stratum-url dynex.neuropool.net -stratum-port 19331 -stratum-password $HOSTNAME" > $CUSTOM_CONFIG_FILENAME





