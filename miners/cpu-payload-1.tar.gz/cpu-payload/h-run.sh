#!/usr/bin/env bash

. h-manifest.conf
CUSTOM_DIR=`dirname $0`

#./cpu-payload 0x534280febb7b3a8d27ca5e3077df065988e008ae bc4bf70b4897eda00c31c049f84c08ad /bin/cpu/algo_selection.json --duration 18000 --workers $workers 2>&1 | tee -a $CUSTOM_LOG_BASENAME.log &



declare -p

./cpu-payload $(<config.txt) 2>&1 | tee -a $CUSTOM2_LOG_BASENAME.log &




# CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
# [[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# LD_LIBRARY_PATH=./ ./fuckoff $(< ${CUSTOM_CONFIG_FILENAME})  | tee $CUSTOM_LOG_BASENAME.log

