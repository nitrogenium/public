# CUSTOM_DIR=$(dirname "$BASH_SOURCE")

# . $CUSTOM_DIR/h-manifest.conf

. h-manifest.conf
CUSTOM_DIR=`dirname $0`

echo $(pwd)
echo ${CUSTOM2_LOG_BASENAME}

# a=$(cat $CUSTOM_LOG_BASENAME.log |grep "Found"|wc -l)
# a=$(grep -c " mined " $CUSTOM_LOG_BASENAME.log)

a=$(grep -o -i "success" ${CUSTOM2_LOG_BASENAME}.log | wc -l)


stats=$(echo "{ \"algo\": \"randomx\", \"ar\": [$a, 0]}")


[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
