. $CUSTOM2_MINER/h-manifest.conf

a=$(grep -o -i "success" ${CUSTOM2_LOG_BASENAME}.log | wc -l)

stats=$(echo "{ \"algo\": \"randomx\", \"ar\": [$a, 0]}")


[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
