CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

[[ -z $CUSTOM2_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM2_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM2_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 2

echo "$CUSTOM2_USER_CONFIG" > algo_selection.json

cpu_threads=$(grep -c '^processor' /proc/cpuinfo)

CONFIG="${CUSTOM2_TEMPLATE} ${CUSTOM2_URL} algo_selection.json --workers $cpu_threads"

echo "$CONFIG" > config.txt


