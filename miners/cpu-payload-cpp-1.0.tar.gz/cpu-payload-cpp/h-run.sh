#!/usr/bin/env bash
set -euo pipefail

# Minimal runner: start one process, pass worker and user args, tee logs

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]:-$0}")" && pwd)"
source "${SCRIPT_DIR}/h-manifest.conf"

if [[ ! -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
  echo "[h-run] config not found: ${CUSTOM_CONFIG_FILENAME}" >&2
  exit 1
fi
source "${CUSTOM_CONFIG_FILENAME}"

LOG_DIR="$(dirname "${CUSTOM_LOG_BASENAME}")"
mkdir -p "$LOG_DIR"

echo "[h-run] ${CUSTOM_BIN} -w '${WALLET_WORKER}' ${USER_ARGS:-}" >&2

if [[ -n "${USER_ARGS:-}" ]]; then
  "${CUSTOM_BIN}" -w "${WALLET_WORKER}" ${USER_ARGS} 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
else
  "${CUSTOM_BIN}" -w "${WALLET_WORKER}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
fi