#!/usr/bin/env bash
set -euo pipefail

# Minimal runner: start one process, pass worker and user args, tee logs

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]:-$0}")" && pwd)"
source "${SCRIPT_DIR}/h-manifest.conf"

if [[ ! -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
  echo "[h-run] config not found: ${CUSTOM_CONFIG_FILENAME}" >&2
  exit 1
fi
source "${CUSTOM_CONFIG_FILENAME}"

LOG_DIR="$(dirname "${CUSTOM_LOG_BASENAME}")"
mkdir -p "$LOG_DIR"

# Only Linux is supported for running
OS_NAME="$(uname -s)"
if [[ "$OS_NAME" != "Linux" ]]; then
  echo "[h-run] ERROR: supported only on Linux. Detected '$OS_NAME'." >&2
  exit 1
fi

# Decide which binary to run (auto-detect CPU flags; fall back to SAFE)
BIN_FAST="${CUSTOM_BIN}"
BIN_SAFE="${CUSTOM_MINER_DIR}/bin/cpu-payload-safe"

choose_bin_variant() {
  # FORCE_SAFE=1 to override detection
  if [[ "${FORCE_SAFE:-0}" == "1" ]]; then
    echo safe; return 0
  fi

  # Linux-only detection
  local flags
  flags=""
  if [[ -r /proc/cpuinfo ]]; then
    flags="$(grep -m1 -E 'flags|Features' /proc/cpuinfo 2>/dev/null || true)"
  fi
  # Need avx, avx2 and osxsave for the FAST binary compiled with AVX2/FMA
  if [[ -z "$flags" ]] || ! echo "$flags" | grep -qw avx || ! echo "$flags" | grep -qw avx2 || ! echo "$flags" | grep -qw osxsave; then
    echo safe; return 0
  fi
  echo fast; return 0
}

variant="$(choose_bin_variant)"
if [[ "$variant" == "safe" ]]; then
  if [[ -x "$BIN_SAFE" ]]; then
    RUN_BIN="$BIN_SAFE"
  else
    echo "[h-run] WARNING: safe binary missing at '$BIN_SAFE', falling back to fast" >&2
    RUN_BIN="$BIN_FAST"
  fi
else
  RUN_BIN="$BIN_FAST"
fi

echo "[h-run] ${RUN_BIN} -w '${WALLET_WORKER}' ${USER_ARGS:-}" >&2

if [[ -n "${USER_ARGS:-}" ]]; then
  "${RUN_BIN}" -w "${WALLET_WORKER}" ${USER_ARGS} 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
else
  "${RUN_BIN}" -w "${WALLET_WORKER}" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
fi