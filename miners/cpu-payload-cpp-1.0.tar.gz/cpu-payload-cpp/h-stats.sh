#!/usr/bin/env bash
# No set -euo pipefail: HiveOS sources this file

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]:-$0}")" && pwd)"
source "${SCRIPT_DIR}/h-manifest.conf"

# API endpoint is fixed to avoid env conflicts in HiveOS
json=$(curl -s --max-time 2 "http://127.0.0.1:8081/" 2>/dev/null || echo "")
if [[ -z "$json" ]]; then
  stats='{"hs":[0],"hs_units":"sols","algo":"unknown","ver":"t: 0 g: 0","ar":[0,0],"uptime":0}'
  khs=0
  return 0 2>/dev/null || exit 0
fi

# Pull fields from API
uptime=$(echo "$json" | jq -r '.uptime_sec // 0' 2>/dev/null)
acc=$(echo "$json" | jq -r '.shares.accepted // 0' 2>/dev/null)
rej=$(echo "$json" | jq -r '.shares.rejected // 0' 2>/dev/null)
avg_sols=$(echo "$json" | jq -r '.last_long_job.avg_sol_per_sec // 0' 2>/dev/null)
t=$(echo "$json" | jq -r '.last_long_job.threads // 0' 2>/dev/null)
g=$(echo "$json" | jq -r '.last_long_job.groups // 0' 2>/dev/null)

# Algo from config if present
ALGO="unknown"
if [[ -f "${CUSTOM_CONFIG_FILENAME}" ]]; then
  source "${CUSTOM_CONFIG_FILENAME}" 2>/dev/null || true
fi

stats='{"hs":['"${avg_sols:-0}"'],"hs_units":"sols","algo":"'"${ALGO:-unknown}"'","ver":"t: '"${t:-0}"' g: '"${g:-0}"'","ar":['"${acc:-0}"','"${rej:-0}"'],"uptime":'"${uptime:-0}"'}'

# Convert to khs
khs=$(awk "BEGIN {printf \"%.6f\", ${avg_sols:-0} / 1000}")
[[ -z "$khs" ]] && khs=0
[[ -z "$stats" ]] && stats='{"hs":[0],"hs_units":"sols","algo":"unknown","ver":"t: 0 g: 0","ar":[0,0],"uptime":0}'