#!/usr/bin/env bash

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

# Читаем файл лога
logfile=$CUSTOM_LOG_BASENAME.log
total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

# Функция для конвертации скорости в kh/s и ее округления
convert_to_khs() {
    speed=$1
    # Извлекаем значение и единицу измерения
    value=$(echo $speed | awk '{print $1}')
    unit=$(echo $speed | awk '{print $2}')

    if [ "$unit" = "gh/s" ]; then
        # Конвертируем из gh/s в kh/s
        value=$(echo "scale=2; $value*1000000" | bc)
    elif [ "$unit" = "mh/s" ]; then
        # Конвертируем из mh/s в kh/s
        value=$(echo "scale=2; $value*1000" | bc)
    fi

    # Округляем до целых и выводим
    printf "%.0f\n" $value
}

# Функция для конвертации скорости в mh/s и ее округления
convert_to_mhs() {
    speed=$1
    # Извлекаем значение и единицу измерения
    value=$(echo $speed | awk '{print $1}')
    unit=$(echo $speed | awk '{print $2}')

    if [ "$unit" = "gh/s" ]; then
        # Конвертируем из gh/s в mh/s
        value=$(echo "scale=2; $value*1000" | bc)
    elif [ "$unit" = "kh/s" ]; then
        # Конвертируем из kh/s в mh/s
        value=$(echo "scale=2; $value/1000" | bc)
    fi

    # Округляем до целых и выводим
    printf "%.0f\n" $value
}

# Извлекаем и округляем последнюю общую скорость
total_speed=$(grep -oP 'Total hashrate: \K[0-9]+\.[0-9]+ [a-z]+/s' $logfile | tail -1)
total_speed_khs=$(convert_to_khs "$total_speed")

# Извлекаем и округляем последние значения скоростей карт (до 12)
card_speeds=$(grep -oE 'NVIDIA.*: [0-9]+\.[0-9]+ [a-z]+/s' $logfile | tail -$total_gpu_count | while read -r line ; do
    speed=$(echo $line | awk '{print $(NF-1), $NF}')
    speed_mhs=$(convert_to_mhs "$speed")
    echo -n "$speed_mhs, "
done | sed 's/, $//')

# Вывод переменных
echo "Общая скорость (kh/s): $total_speed_khs"
echo "Скорость по картам (mh/s): $card_speeds"


stats=$(echo "{\"hs\": [$card_speeds], \"hs_units\":\"ghs\", \"total_khs\":\"$total_speed_khs\", \"algo\": \"randomx\"}")
khs=$total_speed_khs


