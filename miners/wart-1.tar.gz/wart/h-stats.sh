#!/usr/bin/env bash

CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf



# Читаем файл лога
logfile=$CUSTOM_LOG_BASENAME.log

# Извлекаем и округляем последнюю общую скорость
total_speed=$(grep -oP 'Total hashrate: \K[0-9]+\.[0-9]+' $logfile | tail -1 | awk '{printf "%.2f", $1}')

# Извлекаем и округляем последние 8 значений скоростей карт
card_speeds=$(grep -oP 'NVIDIA CMP 50HX: \K[0-9]+\.[0-9]+' $logfile | tail -8 | awk '{printf "%.2f, ", $1}' | sed 's/, $//')

# Вывод переменных
echo "Общая скорость: $total_speed"
echo "Скорость по картам: $card_speeds"


 stats=$(echo "{\"hs\": [$card_speeds], \"hs_units\":\"ghs\", \"total_khs\":\"$total_speed\", \"algo\": \"randomx\"}")



