
extra="${CUSTOM_USER_CONFIG}"
conf="SEED=${CUSTOM_TEMPLATE}"

echo "$conf" > JettonGramGpuMiner/config.txt
echo "$extra" > JettonGramGpuMiner/extra.txt

