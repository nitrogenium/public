CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

extra="${CUSTOM_USER_CONFIG}"
conf="SEED=${CUSTOM_TEMPLATE}"

echo "$conf" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/config.txt
echo "$extra" > /hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/extra.txt