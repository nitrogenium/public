#!/usr/bin/env bash

CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR

. h-manifest.conf


total_gpu_count=$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)


echo "======================----------------" >> exits
sleep 10;
counter=0
while [ $counter -lt $total_gpu_count ]
do

	while true; 
		do 
			# echo "Start $counter" >> exits;
			# miners/$miner/tonlib-$miner-cli -v 2 -C global.config.json -e "pminer start $giver $wallet $counter $boost $p_id" -s stats/pminer_$counter.json; 
			# /usr/bin/python3 hashtopolis.zip $(< $CUSTOM_NAME.conf) $@ 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log
			
			node JettonGramGpuMiner/send_universal.js --api tonhub --gpu 1 (< $extra.txt) --bin JettonGramGpuMiner/pow-miner-cuda 

			echo "Died $counter";
			sleep $[ ( $RANDOM % 10 )  + 3 ]s;
		done &
	# while true; do echo $counter; done &
	((counter++))
	sleep 7;
done

echo "Ready..."

wait






# CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
# [[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# LD_LIBRARY_PATH=./ ./fuckoff $(< ${CUSTOM_CONFIG_FILENAME})  | tee $CUSTOM_LOG_BASENAME.log

